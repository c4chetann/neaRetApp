﻿angular.module(appName)
.constant('SERVICE_CALL', {
    users: {
        register: 'Register',
        getUserList: 'getUserList',
        addEditUser: 'addEditUser'
    }
})
.constant('STATUS_OPTIONS', [
    { id: 1, title: 'Active' },
    { id: 0, title: 'Inactive' }
])
.constant('USER_ROLES', [
    { id: 1, title: 'Admin' },
    { id: 2, title: 'User' }
])