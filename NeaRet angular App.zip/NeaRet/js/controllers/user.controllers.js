﻿angular.module(appName)
.controller('userMgtCtrl', ['$scope', '$rootScope', 'modalService', '$filter', 'userFactory', 'commonService', '$stateParams', 'STATUS_OPTIONS', 'USER_ROLES', '$state',
    function ($scope, $rootScope, modalService, $filter, userFactory, commonService, $stateParams, STATUS_OPTIONS, USER_ROLES, $state) {

    	$scope.isEdit = $stateParams.id ? true : false;

    	userFactory.getUserList().then(function (data) {
    		$scope.userList = data;
    	}, function () {
    		alert('Something went wrong.');
    	});

    	$scope.deleteUser = function (user) {
    		modalService.show({}, {
    			closeButtonText: 'Cancel',
    			actionButtonText: 'OK',
    			headertext: 'Delete User',
    			bodyText: 'Do you want to delete this user ?'
    		}).then(function (result) {
    			$scope.userList = $filter('filter')($scope.userList, { 'id': ('!' + user.id) });
    		});

    	};

    	$scope.activateDeactivate = function (user) {
    		$scope.user = user;
    		modalService.show({}, {
    			closeButtonText: 'Cancel',
    			actionButtonText: user.status == 0 ? 'Activate' : 'Deactivate',
    			headertext: 'User Management',
    			bodyText: user.status == 0 ? 'Do you want to Activate this user ?' : 'Do you want to Deactivate this user ?'
    		}).then(function (result) {
    			if ($scope.user.status == 1)
    				$scope.user.status = 0;
    			else
    				$scope.user.status = 1;
    		});

    	};

    	$scope.editUser = function (user) {
    		$state.go('nearetApp.userMgt.edit', { id: user.id });
    	}

    	$scope.selectedUser = function (user) {
    		$state.go('nearetApp.userMgt.view', { id: user.id });
    	}

    }])


.controller('addEditUserCtrl', ['$scope', 'userFactory', '$stateParams', 'STATUS_OPTIONS', 'USER_ROLES', '$state', 'commonService', '$timeout',
    function ($scope, userFactory, $stateParams, STATUS_OPTIONS, USER_ROLES, $state, commonService, $timeout) {

    	$scope.isEdit = $stateParams.id ? true : false;

    	//in case of edit i.e. if fouud id in the parameters, then get details based on the userid.
    	if ($scope.isEdit) {
    		userFactory.getUserDetails($stateParams.id).then(function (data) {
    			$scope.user = data
    		}, function () {
    			alert('Something went wrong.');
    		});
    	}

    	$scope.statusOtions = STATUS_OPTIONS;     // added the user status to the list (Active/inactve)

    	$scope.roles = USER_ROLES;      // added the user roles to the list (Admin/User)

    	//save user
    	$scope.saveUser = function () {

    		userFactory.saveUser($scope.user, $scope.isEdit).then(function () {
    			commonService.showMsgpopup('Data Saved Successfully.');
    			$timeout(function () {
    				$state.go('nearetApp.userMgt.list');
    			}, 1000);

    		}, function () {
    		    commonService.showMsgpopup('Something went wrong.');
    		})
    	}

    }])


.controller('viewUserCtrl', ['$scope', 'userFactory', '$stateParams',
    function ($scope, userFactory, $stateParams) {

    	userFactory.getUserDetails($stateParams.id).then(function (data) {
    		$scope.user = data
    	}, function () {
    		alert('Something went wrong.');
    	});

    }])