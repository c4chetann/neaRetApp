﻿angular.module(appName)
.controller('appController', ['$rootScope', '$scope', '$state', 'userFactory', '$timeout', 'commonService', function ($rootScope, $scope, $state, userFactory, $timeout, commonService) {
   
    $scope.loginUser = function () {
        $state.go('nearetApp.userMgt.list');
    };

    $scope.logout = function () {
        $state.go('login');
    };

    $scope.register = {};
    $scope.registerUser = function () {
        userFactory.registerUser($scope.register).then(function () {
            commonService.showMsgpopup('Data Saved Successfully.');
            $timeout(function () {
                $state.go('login');
            }, 1000);
        }, function () {
            commonService.showMsgpopup('Something went wrong.');
        });

    }
}]);