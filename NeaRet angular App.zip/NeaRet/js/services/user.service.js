﻿
// Hard coded user list
var userList = [{ id: 1, name: 'Chetan ', email: 'me@chetann.com', phone: '9813265283', status: 1, role: 1 },
   { id: 2, name: 'Kamal', email: 'kamal@mail.com', phone: '9813265222', status: 0, role: 2 },
   { id: 3, name: 'Pankaj', email: 'admin@gmail.com', phone: '9813265283', status: 1, role: 1 },
   { id: 4, name: 'Rohit ', email: 'me@rohit.com', phone: '9813265283', status: 0, role: 2 },
   { id: 5, name: 'Deepak ', email: 'me@deepak.com', phone: '9813265283', status: 1, role: 1 }];

angular.module(appName)
.factory('userFactory', ['$http', '$q', 'SERVICE_CALL', 'commonService', '$filter', function ($http, $q, SERVICE_CALL, commonService, $filter) {

	var userFactory = {};
	userFactory.registerUser = function (data) {

	    var deferred = $q.defer();

	    data['id'] = userList.length + 1;
	    data['role'] = 2;
	    data['status'] = 0;
	    userList.push(data);

		// code for makeing a hhtp call to ther server.
		//$http(commonService.createHttpRequestObject(SERVICE_CALL.users.register, data))
		//    .success(function (res) {
		//        if (res.success) {
		//            deferred.resolve(res.data);
		//        } else {
		//            deferred.reject(res.error);
		//        }
		//    }).
		//    error(function () {
		//        commonService.showMsgpopup();
		//    })
		deferred.resolve(true);
		return deferred.promise;
	}

	userFactory.getUserList = function (data) {
		var deferred = $q.defer();
		deferred.resolve(userList);
		return deferred.promise;
	}

	userFactory.getUserDetails = function (data) {
		var deferred = $q.defer();

		deferred.resolve($filter('filter')(userList, { 'id': data })[0]);
		return deferred.promise;
	}

	userFactory.saveUser = function (data, isEdit) {
		var deferred = $q.defer();
		if (isEdit) {
			angular.forEach(userList, function (user) {
				if (user.id == data.id) {
					user = data;
				}
			})

		} else {
			data['id'] = userList.length + 1;
			userList.push(data);
		}
		deferred.resolve(true);
		return deferred.promise;
	}

	return userFactory;

}])
