﻿
// Hard coded user list
var userList = [{ id: 1, name: 'Chetan ', email: 'me@chetann.com', phone: '9813265283', status: 1, role: 1 },
   { id: 2, name: 'Kamal', email: 'kamal@mail.com', phone: '9813265222', status: 0, role: 2 },
   { id: 3, name: 'Pankaj', email: 'admin@gmail.com', phone: '9813265283', status: 1, role: 1 },
   { id: 4, name: 'Rohit ', email: 'me@rohit.com', phone: '9813265283', status: 0, role: 2 },
   { id: 5, name: 'Deepak ', email: 'me@deepak.com', phone: '9813265283', status: 1, role: 1 }];
angular.module(appName)
.factory('commonService', ['$http', '$q', '$rootScope', 'modalService', function ($http, $q, $rootScope, modalService) {
    var commonService = {};
    var servicesUrl = 'http://192.168.1.202:8080/services/';
    // to create a post/get object
    commonService.createHttpRequestObject = function (action, data, method, headers) {
        var req = {};
        req['method'] = method || 'POST';
        if (action) {
            req['url'] = servicesUrl + action;
        }
        if (data) {
            req['data'] = data;
        }
        req['headers'] = headers || { 'Content-Type': 'application/x-www-form-urlencoded' };
        return req;
    }
    commonService.showMsgpopup = function (msg) {
        var errMsg = msg == undefined ? 'Something went wrong.' : msg;
        modalService.show({}, {
            actionButtonText: 'OK',
            headerText: 'NeaRet',
            bodyText: errMsg,
            showCloseButton: false
        });
    }
    return commonService;
}
])

.factory('userFactory', ['$http', '$q', 'SERVICE_CALL', 'commonService', '$filter', function ($http, $q, SERVICE_CALL, commonService, $filter) {

    var userFactory = {};
    userFactory.registerUser = function (data) {

        var deferred = $q.defer();
        // code for makeing a hhtp call to ther server.
        //$http(commonService.createHttpRequestObject(SERVICE_CALL.users.register, data))
        //    .success(function (res) {
        //        if (res.success) {
        //            deferred.resolve(res.data);
        //        } else {
        //            deferred.reject(res.error);
        //        }
        //    }).
        //    error(function () {
        //        commonService.showMsgpopup();
        //    })
        deferred.resolve(true);
        return deferred.promise;
    }

    userFactory.getUserList = function (data) {
        var deferred = $q.defer();
        deferred.resolve(userList);
        return deferred.promise;
    }

    userFactory.getUserDetails = function (data) {
        var deferred = $q.defer();
       
        deferred.resolve($filter('filter')(userList, { 'id': data })[0]);
        return deferred.promise;
    }

    userFactory.saveUser = function (data, isEdit) {
        var deferred = $q.defer();
        if (isEdit) {
            angular.forEach(userList, function (user) {
                if (user.id == data.id) {
                    user = data;
                }
            })

        } else {
            data['id'] = userList.length + 1;
            userList.push(data);
        }
        deferred.resolve(true);
        return deferred.promise;
    }

    return userFactory;

}])

.service('modalService', ['$modal', function ($modal) {

    var modalOptions = {
        closeButtonText: 'Close',
        actionButtonText: 'OK',
        headerText: 'Confirmation',
        bodyText: 'Are you sure you want to perform this action?',
        showCloseButton: true
    };

    var modalDefaults = {
        backdrop: true,
        keyboard: true,
        templateUrl: 'views/core/modal.html'
    };

    this.show = function (customModalDefaults, customModalOptions) {
        //Create temp objects to work with since we're in a singleton service
        var tempModalDefaults = {};
        var tempModalOptions = {};

        //Map angular-ui modal custom defaults to modal defaults defined in service
        angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

        //Map modal.html $scope custom properties to defaults defined in service
        angular.extend(tempModalOptions, modalOptions, customModalOptions);

        if (!tempModalDefaults.controller) {
            tempModalDefaults.controller = function ($scope, $modalInstance) {
                $scope.modalOptions = tempModalOptions;
                $scope.confirm = function (result) {
                    $modalInstance.close(result);
                };
                $scope.close = function (result) {
                    $modalInstance.dismiss('cancel');
                };
            }
        }

        return $modal.open(tempModalDefaults).result;
    };

}]);
