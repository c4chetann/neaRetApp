﻿var appName = 'nearetApp';
var appDependencies = ['ui.router', 'ui.bootstrap'];


angular.module(appName, appDependencies)

angular.element(document).ready(function () {
    angular.bootstrap(document, [appName]);
});