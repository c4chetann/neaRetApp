angular.module(appName)
.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/login');

    $stateProvider
        .state('nearetApp', {
            templateUrl: 'views/core/app.html',
            abstract: true
        })
   
        .state('nearetApp.userMgt', {
            url: '/users',
            template: '<div ui-view></div>',
            abstract: true
        })
        .state('nearetApp.userMgt.list', {
            url: '/list',
            templateUrl: 'views/userMgt/list.html',
            controller: 'userMgtCtrl'
        })

        .state('nearetApp.userMgt.add', {
            url: '/add',
            templateUrl: 'views/userMgt/addEdit.html',
            controller: 'addEditUserCtrl'
        })

        .state('nearetApp.userMgt.edit', {
            url: '/edit/:id',
            templateUrl: 'views/userMgt/addEdit.html',
            controller: 'addEditUserCtrl'
        })

        .state('nearetApp.userMgt.view', {
            url: '/view/:id',
            templateUrl: 'views/userMgt/view.html',
            controller: 'viewUserCtrl'

        })
        /* -------------------------------Auth States   ------------------------------- */

        .state('login', {
            url: '/login',
            data: { pageTitle: 'Login' },
            templateUrl: 'views/core/login.html',
            controller: 'appController'
        })
        .state('register', {
            url: '/register-user',
            data: { pageTitle: 'Register' },
            templateUrl: 'views/core/register.html',
            controller: 'appController'

        })
}])
.run(['$rootScope', '$state', function ($rootScope, $state) {
}])